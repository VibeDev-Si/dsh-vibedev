/**
 * Audio generation requests — music, podcasts and speech — checked against what
 * the chosen model declares in the catalog's `audio` block, and turned into the
 * body of `POST /v1/audio/generations`.
 *
 * Each kind sends only its own fields:
 *
 * | kind    | wire fields                                                     |
 * | ------- | --------------------------------------------------------------- |
 * | music   | model, prompt, lyrics, genre, mood, gender                      |
 * | podcast | model, prompt, source_url                                       |
 * | speech  | as declared; Seed: model, text_prompt, references, audio_config, watermark |
 *
 * The main text goes in the model's `prompt_field`. A field the model does not
 * declare in `request_fields` is refused before anything is uploaded or charged;
 * music and podcasts never take speech references, output formats, sample rates
 * or a duration. Speech references, formats and sample rates come from the
 * catalog only (count, size, length, mutual exclusions, the sample rates of
 * each format), never from a fixed list.
 * @module dsh-vibedev/audio/request
 */
import type { AudioCapabilities, AudioGenerationKind, MediaModel } from '../gateway/catalog.js';
import type { AudioQuote } from '../pricing.js';
import type { MediaCall, MediaRuntime } from '../runtime.js';
import type { TaskRecord } from '../tasks/store.js';
/** The kinds of audio a generation request makes. */
export type AudioMakeKind = Exclude<AudioGenerationKind, 'transcription'>;
export declare const AUDIO_MAKE_KINDS: readonly AudioMakeKind[];
/** What to generate. Unset fields are not sent. */
export interface AudioRequest {
    /** What to make; with a named model it must match the model's declared kind. */
    readonly kind?: AudioMakeKind;
    /** A model id or alias; otherwise the pinned or first model of the kind. */
    readonly model?: string;
    /** The main text: a song description, a podcast topic, or the words to speak. */
    readonly prompt?: string;
    /** Music. */
    readonly lyrics?: string;
    readonly genre?: string;
    readonly mood?: string;
    readonly gender?: string;
    /** Podcast: an http(s) page for the hosts to discuss. */
    readonly sourceUrl?: string;
    /** Speech: reference audio (a voice to imitate) — workspace paths, links or `chat:` attachments. */
    readonly references?: readonly string[];
    /** Speech: an output format the model declares (`wav`, `mp3`, …). */
    readonly format?: string;
    /** Speech: a sample rate the model declares for that format. */
    readonly sampleRate?: number;
    /** Speech: whether the provider adds its watermark, when the model takes the field. */
    readonly watermark?: boolean;
    /** Not an audio-generation parameter; refused for music and podcasts, and for speech unless declared. */
    readonly duration?: number;
    /**
     * One user operation's key: the same key always answers with the same task,
     * so a repeated click or a retried call never creates a second one. Letters,
     * digits, `-` and `_`, at most 80. Generated when absent.
     */
    readonly operationId?: string;
}
/**
 * What an audio model makes, from its declaration only.
 * @param model - the model.
 * @returns the kind, or undefined when the catalog does not declare it.
 */
export declare function audioKindOf(model: MediaModel): AudioMakeKind | undefined;
/** The wire fields a model takes. */
export declare function requestFieldsOf(model: MediaModel): readonly string[];
/** The field the main text goes in. */
export declare function promptFieldOf(model: MediaModel): string | undefined;
/** The output format and sample rate a speech request uses, from the declared formats only. */
export declare function audioConfigOf(model: MediaModel, format: string | undefined, sampleRate: number | undefined): {
    format: string;
    sample_rate?: number;
} | undefined;
/**
 * Check a request against the model and build the body, without references
 * (they are uploaded first; their URLs are added by {@link prepareAudioTask}).
 * @param model - the chosen model.
 * @param request - what to generate.
 * @returns the body without references, and the wire fields the request uses.
 * @throws {@link MediaError} for a field the model does not take, a missing text, or a value outside the declared choices.
 */
export declare function audioRequestBody(model: MediaModel, request: AudioRequest): Record<string, unknown>;
/**
 * Choose the model for a request: the one named (an id or an alias), else the
 * pinned or first model of the kind. A named model must make the kind asked for.
 */
export declare function chooseAudioModel(runtime: MediaRuntime, request: Pick<AudioRequest, 'kind' | 'model'>, signal?: AbortSignal): Promise<MediaModel>;
/** A checked, priced audio task ready to submit. */
export interface PreparedAudio {
    readonly model: MediaModel;
    readonly kind: AudioMakeKind;
    readonly quote: AudioQuote;
    readonly draft: TaskRecord;
}
/**
 * Everything before an audio submission: choose the model, check every field
 * against its declaration, upload and measure speech references, price it,
 * confirm the spending, and build the task under the operation's key.
 * @param runtime - the media runtime.
 * @param call - the tool call or host call.
 * @param request - what to generate.
 * @param save - where the result goes.
 * @returns the prepared task.
 */
export declare function prepareAudioTask(runtime: MediaRuntime, call: MediaCall, request: AudioRequest, save: {
    readonly folder: string;
    readonly stem: string;
}): Promise<PreparedAudio>;
/** One field of an audio form, for interfaces that build their form from the catalog. */
export interface AudioFormField {
    /** The {@link AudioRequest} key. */
    readonly key: 'prompt' | 'lyrics' | 'genre' | 'mood' | 'gender' | 'sourceUrl' | 'references' | 'format' | 'sampleRate' | 'watermark';
    /** The wire field it is sent as. */
    readonly wire: string;
    readonly required: boolean;
    /** Declared choices. */
    readonly choices?: readonly string[];
    /** For `sampleRate`: the rates of each format. */
    readonly sampleRates?: Readonly<Record<string, readonly number[]>>;
    /** For `references`: the declared limits. */
    readonly limits?: NonNullable<AudioCapabilities['references']>;
    readonly maxChars?: number;
}
/** What a form for one audio model shows. */
export interface AudioForm {
    readonly model: string;
    readonly name: string;
    readonly kind: AudioMakeKind;
    readonly fields: readonly AudioFormField[];
    readonly price: AudioQuote;
    readonly defaultFormat?: string;
}
/**
 * The form an interface shows for one model: only the fields the model
 * declares, with their declared choices and limits.
 * @param model - the model.
 * @returns the form, or undefined for a model that cannot generate audio.
 */
export declare function audioFormOf(model: MediaModel): AudioForm | undefined;
