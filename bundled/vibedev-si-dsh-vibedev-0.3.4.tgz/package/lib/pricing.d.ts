/**
 * Price estimates from the catalog's `media_pricing` (selling prices with the
 * account multiplier applied). The gateway estimates the same way at admission:
 * per-second video prices times billed seconds, where billed seconds are the
 * output length plus the summed reference video length, rounded up once.
 * Estimates are for the user's information; the gateway's receipt is the charge.
 *
 * Video models priced per video Token (`video_pricing`) are quoted by
 * {@link quoteVideo}: the matching rule's per-second estimate times the output
 * length plus every reference video's length, in exact decimals. The final
 * charge is the provider's billable Tokens times the rule's Token price, so a
 * Token price is never shown as an unconditional per-second price, never as
 * 未定价 and never as free — and what cannot be estimated says so.
 *
 * A model without a price is "not priced" (未定价), never free: only a price the
 * catalog states as zero is shown as ¥0.
 * @module dsh-vibedev/pricing
 */
import type { MediaKind, MediaModel, PriceUnit } from './gateway/catalog.js';
/** One estimate. */
export interface Estimate {
    readonly amountCny: number;
    /** How it was reached, such as `¥0.99/s × 5 s`. */
    readonly basis: string;
}
/** Text in both languages the plugin speaks. */
export interface Bilingual {
    readonly en: string;
    readonly zh: string;
}
/** Shown wherever the catalog gives no price. */
export declare const UNPRICED: Bilingual;
/**
 * Format an amount in yuan: two decimals, more when a small unit price needs them (`¥0.015`).
 * @param amount - the amount.
 * @returns `¥4.95`.
 */
export declare function yuan(amount: number): string;
/**
 * The unit after a price: `/s`, `/原始秒`, `/次`.
 * @param unit - the price unit.
 * @param kind - the kind of model, which names a generation (an image, a video, a request).
 * @returns the suffix in both languages.
 */
export declare function unitSuffix(unit: PriceUnit, kind: MediaKind): Bilingual;
/**
 * A one-line price for listings: `¥0.10 per image`, `¥0.99/s (720p)`; `not priced` without a price.
 * A video Token price lists its rules (`视频 Token 计价：480p 无参考视频 ¥60.06/百万 Token（预计 ¥0.5819/秒）…`).
 * @param model - the model.
 * @param lang - the language.
 * @returns the price line.
 */
export declare function describePrice(model: MediaModel, lang?: keyof Bilingual): string;
/**
 * Estimate an image request.
 * @param model - the image model.
 * @param count - images requested.
 * @returns the estimate, or undefined without a price.
 */
export declare function estimateImages(model: MediaModel, count: number): Estimate | undefined;
/**
 * Estimate a video request.
 * @param model - the video model.
 * @param duration - the requested length in seconds, when given.
 * @param resolution - the requested resolution, when given.
 * @param referenceMs - the summed length of the reference videos.
 * @returns the estimate, or undefined without a price.
 */
export declare function estimateVideo(model: MediaModel, duration: number | undefined, resolution: string | undefined, referenceMs?: number): Estimate | undefined;
/** What an audio request costs, as far as it can be known before it runs. */
export interface AudioQuote {
    /** The catalog states a price. */
    readonly priced: boolean;
    readonly unit?: PriceUnit;
    readonly unitPriceCny?: number;
    /**
     * The amount, when it is known before the request runs: per generation, or
     * per minute of an input whose length was measured. Speech billed per
     * original second is known only once the provider reports that length.
     */
    readonly amountCny?: number;
    /** The unit price: `¥0.50/次`, `¥0.02/原始秒`, `¥0.30/分钟`, or `未定价`. */
    readonly label: Bilingual;
    /** How the charge is reached. */
    readonly basis: Bilingual;
}
/**
 * Quote an audio request: music, podcast and speech generation, or a transcription.
 * @param model - the audio or transcription model.
 * @param inputSeconds - for a transcription, the measured length of the input, when known.
 * @returns the quote; `priced: false` (未定价) when the catalog gives no usable price.
 */
export declare function quoteAudio(model: MediaModel, inputSeconds?: number): AudioQuote;
/** A video request to quote, before anything is uploaded or submitted. */
export interface VideoQuoteRequest {
    /** The canonical model id or an alias. */
    readonly model: string;
    /** When absent and the catalog offers exactly one resolution for the model, that one. */
    readonly resolution?: string;
    /** The requested output length. */
    readonly durationSeconds?: number;
    readonly references?: {
        /** One entry per reference video; an absent `durationSeconds` is unknown, not zero. */
        readonly videos?: readonly {
            readonly durationSeconds?: number;
        }[];
        /** Image references, first and last frames included. */
        readonly images?: number;
        /** Reference audios (generating audio is not a reference audio). */
        readonly audios?: number;
    };
}
/** The conditions of the rule a quote used. */
export interface VideoQuoteRule {
    readonly resolution: string;
    readonly referenceVideo?: boolean;
    readonly referenceAudio?: boolean;
    readonly referenceImage?: boolean;
}
/** Why a video request has no estimate. */
export type VideoQuoteReason = 'no-price' | 'unknown-schema' | 'invalid-pricing' | 'no-matching-rule' | 'ambiguous-rules' | 'missing-resolution' | 'missing-duration' | 'unknown-reference-duration' | 'no-estimated-price' | 'invalid-request';
/** An estimate under video Token pricing; the final charge is the actual video Tokens times the Token price. */
export interface VideoTokenEstimate {
    readonly status: 'estimate';
    readonly mode: 'video_token';
    readonly model: string;
    readonly currency: 'CNY';
    /** Exact decimal, never rounded (`2.9095`); labels round half up to two decimals. */
    readonly amountCny: string;
    readonly estimatedPricePerSecondCny: number;
    readonly pricePerMillionTokensCny: number;
    readonly outputSeconds: number;
    readonly referenceVideoSeconds: number;
    readonly billedSeconds: number;
    readonly rule: VideoQuoteRule;
    readonly estimateOnly: true;
    readonly finalBasis: 'provider_tokens';
    /** `预计 ¥8.34 · 最终按实际视频 Token 结算`. */
    readonly label: Bilingual;
    /** `¥0.6952/秒 × (7 秒输出 + 5 秒参考视频)，¥36.036/百万 Token`. */
    readonly basis: Bilingual;
}
/** An estimate from a legacy `media_pricing` price (per second or per generation). */
export interface VideoLegacyEstimate {
    readonly status: 'estimate';
    readonly mode: 'legacy';
    readonly model: string;
    readonly currency: 'CNY';
    readonly amountCny: string;
    readonly label: Bilingual;
    readonly basis: Bilingual;
}
/** No estimate, and why. Under Token pricing this is never "not priced" and never free. */
export interface VideoQuoteUnavailable {
    readonly status: 'unavailable';
    readonly mode: 'video_token' | 'legacy' | 'none';
    readonly model: string;
    readonly reason: VideoQuoteReason;
    /** The matched rule's Token price, when a rule matched but the amount cannot be estimated. */
    readonly pricePerMillionTokensCny?: number;
    readonly label: Bilingual;
    readonly basis: Bilingual;
}
/** What a video request is expected to cost. */
export type VideoQuote = VideoTokenEstimate | VideoLegacyEstimate | VideoQuoteUnavailable;
/**
 * Quote a video request from the catalog alone: no upload, no submission.
 *
 * Video Token pricing: the unique most specific rule for the resolution and
 * the presence of reference video, audio and images; its per-second estimate
 * times the output length plus every reference video's length. A model whose
 * `video_pricing` cannot be read gets no estimate and never falls back to its
 * legacy price. Legacy models are quoted as {@link estimateVideo} always did.
 * @param model - the resolved model.
 * @param request - the request.
 * @returns the quote.
 */
export declare function quoteVideo(model: MediaModel, request: VideoQuoteRequest): VideoQuote;
/**
 * The estimate a task records: the quote amount half up to two decimals.
 * @param quote - the quote.
 * @returns `8.34`, or undefined without an estimate.
 */
export declare function quotedCny(quote: VideoQuote): string | undefined;
