/**
 * `media_models`: the media models this VibeDev account can use, with prices
 * and, for video, what each generation mode accepts.
 * @module dsh-vibedev/tools/models
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { MediaModel } from '../gateway/catalog.js';
import type { MediaRuntime } from '../runtime.js';
/**
 * What an audio model takes, from its declaration: the fields, speech references, output formats and sample rates.
 * @param model - an audio or transcription model.
 * @returns one line, or undefined when nothing is declared.
 */
export declare function describeAudioModel(model: MediaModel): string | undefined;
/**
 * Build the tool.
 * @param runtime - the media runtime.
 * @returns the tool definition.
 */
export declare function mediaModelsTool(runtime: MediaRuntime): ToolDefinition;
