/**
 * `audio_generate`: music, a podcast episode or speech, as a background task
 * whose results are saved in the workspace. Every field is checked against
 * what the chosen model declares (see `audio/request`).
 * @module dsh-vibedev/tools/audio
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { MediaRuntime } from '../runtime.js';
/**
 * Build the tool.
 * @param runtime - the media runtime.
 * @returns the tool definition.
 */
export declare function audioGenerateTool(runtime: MediaRuntime): ToolDefinition;
