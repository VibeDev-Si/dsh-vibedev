/**
 * Exact decimal arithmetic for money. A value is a scaled integer
 * (`units × 10^-scale`, BigInt), so `0.5819 × 5` is `2.9095` and not
 * `2.9094999999999995`. Catalog prices arrive as JSON numbers; a number is read
 * as the decimal it is written as (its shortest round-trip form), which is the
 * literal the gateway sent.
 * @module dsh-vibedev/util/decimal
 */
/** A decimal number: `units × 10^-scale`. */
export interface Decimal {
    readonly units: bigint;
    readonly scale: number;
}
/**
 * The exact decimal of a finite number (as written by `String`) or a decimal string.
 * @param value - the number or text, such as `0.5819`, `1e-7` or `"3.98066354"`.
 * @returns the decimal.
 * @throws RangeError for anything that is not a finite decimal.
 */
export declare function decimal(value: number | string): Decimal;
/** Zero. */
export declare const ZERO: Decimal;
/**
 * The sum of two decimals.
 * @param a - the first.
 * @param b - the second.
 * @returns `a + b`, exactly.
 */
export declare function add(a: Decimal, b: Decimal): Decimal;
/**
 * The product of two decimals.
 * @param a - the first.
 * @param b - the second.
 * @returns `a × b`, exactly.
 */
export declare function multiply(a: Decimal, b: Decimal): Decimal;
/**
 * Round half up (away from zero) to a number of decimals.
 * @param value - the decimal.
 * @param places - decimals to keep.
 * @returns the rounded decimal.
 */
export declare function roundHalfUp(value: Decimal, places: number): Decimal;
/**
 * Round up to a whole number (towards positive infinity).
 * @param value - the decimal.
 * @returns the smallest whole number not below it.
 */
export declare function ceil(value: Decimal): Decimal;
/**
 * Exact text without trailing zeros (`2.9095`, `5`), padded to at least `minFraction` decimals.
 * @param value - the decimal.
 * @param minFraction - decimals always shown (`5.00` with 2).
 * @returns the text.
 */
export declare function format(value: Decimal, minFraction?: number): string;
/**
 * The nearest number, for fields typed as numbers (never for money amounts).
 * @param value - the decimal.
 * @returns the number.
 */
export declare function toNumber(value: Decimal): number;
