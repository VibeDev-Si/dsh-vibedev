/**
 * The VibeDev account as the plugin's pages see it, and the Host routes they
 * call (`/api/dsh-vibedev/account…`, on the client connection like every
 * plugin route):
 *
 * - `GET  /api/dsh-vibedev/account` — where the credential comes from (the
 *   app's account, the plugin's own sign-in, a development key, or none), who
 *   is signed in, the balance, a sign-in waiting for the browser, and how many
 *   VibeDev models the pickers list; `?fresh=1` reads the balance again;
 *   `?since=<revision>` holds the request until the person or the balance
 *   changes (a charge is read again right after it ends), so the pages show a
 *   new balance within seconds instead of on their next minute poll;
 * - `POST /api/dsh-vibedev/account/sign-in` — `{ open?: boolean }`: start the
 *   plugin's own sign-in; answers the authorization link (`open: false` leaves
 *   opening it to the page);
 * - `POST /api/dsh-vibedev/account/cancel` — stop a waiting sign-in;
 * - `POST /api/dsh-vibedev/account/sign-out` — end the plugin's own sign-in
 *   (an app account is signed out in the app, so that answers 409).
 *
 * The DeepSeek account is never touched: it stays the Harness's own.
 * @module dsh-vibedev/account
 */
import type { ConnectionFetchRoute } from '@deepseek-ai/dsh-client-connection';
import type { CredentialChain } from '../auth/credentials.js';
import type { PluginLogin, SignInAttempt } from '../auth/login.js';
/** Path prefix of the plugin's Host routes. */
export declare const ACCOUNT_ROUTE_PREFIX = "/api/dsh-vibedev/account";
/** Where the active credential comes from. */
export type AccountSource = 'host' | 'plugin' | 'key' | 'none';
/** What the account pages render. */
export interface AccountView {
    readonly source: AccountSource;
    /** The signed-in person, when known. */
    readonly user?: {
        readonly id?: string;
        readonly email?: string;
        readonly nickname?: string;
    };
    /** The balance, when it could be read. */
    readonly balance?: {
        readonly amount: string;
        readonly currency: string;
    };
    /** A sign-in waiting for the browser. */
    readonly pending?: {
        readonly url: string;
        readonly expiresAt: number;
    };
    /** Safe sign-in progress or the most recent terminal diagnostic. */
    readonly attempt?: SignInAttempt;
    /** VibeDev chat models the pickers list now, and why there are none. */
    readonly models: {
        readonly count: number;
        readonly hidden?: 'signed-out' | 'host-account';
    };
    /** Pages on the gateway's site. */
    readonly links: {
        readonly topUp: string;
        readonly register: string;
        readonly usage: string;
    };
    /** The VibeDev account is the app's main account (the VibeDev app): its row leads the sidebar foot and Settings. */
    readonly primary: boolean;
    /**
     * Grows whenever the person or the balance changes; `GET …/account?since=<revision>`
     * answers as soon as it grows (or after a while with the same view).
     */
    readonly revision: number;
}
/** What the account routes need from the plugin. */
export interface AccountServiceOptions {
    readonly origin: string;
    readonly userAgent: string;
    readonly chain: CredentialChain;
    readonly login: PluginLogin;
    /** The VibeDev route's model count and why it is empty. */
    readonly models: () => {
        count: number;
        hidden?: 'signed-out' | 'host-account';
    };
    /** Present the VibeDev account as the app's main account. */
    readonly primary?: boolean;
    readonly fetch?: typeof globalThis.fetch;
    readonly now?: () => number;
    /** Timer seams for the reads after a charge and the long poll. */
    readonly setTimeout?: (callback: () => void, ms: number) => unknown;
    readonly clearTimeout?: (handle: unknown) => void;
}
/** The account state behind the pages. */
export declare class AccountService {
    private readonly options;
    private balanceCache;
    /** A background read of a stale balance, so only one runs at a time. */
    private revalidating;
    private readonly now;
    private revision;
    /** What the last read showed, to tell whether the next one changed anything. */
    private lastSeen;
    private readonly waiters;
    private settleTimers;
    /** Grows with every credential change; a read started before one is dropped. */
    private epoch;
    /** When the last read after a charge started, to space them out. */
    private lastSpendReadAt;
    /**
     * @param options - origin, credential chain, the plugin's sign-in and the route's model state.
     */
    constructor(options: AccountServiceOptions);
    private timeout;
    private cancelTimeout;
    /** Something the pages show changed: answer every waiting `?since=` request. */
    changed(): void;
    /** The account changed hands (sign-in, sign-out, switch): forget the balance and tell the pages. */
    credentialChanged(): void;
    /**
     * A request that may have cost money ended (a chat reply, a generation, a
     * transcription): read the balance again shortly, and once more later if the
     * charge had not settled yet. Repeated calls in a burst share the reads.
     */
    spent(): void;
    /** Read the balance of the current credential now (the pages hear about a change through the long poll). */
    private readNow;
    /**
     * Wait until the view changes past `since`, or a while.
     * @param since - the revision the page shows.
     * @param signal - the page went away.
     * @returns once there is something new, or the wait ran out.
     */
    wait(since: number, signal?: AbortSignal): Promise<void>;
    /** Links to the gateway's pages. */
    links(): AccountView['links'];
    /**
     * The account as it stands.
     * @param fresh - read the balance again instead of reusing a recent read.
     * @returns the view.
     */
    view(fresh?: boolean): Promise<AccountView>;
    /**
     * `GET /v1/account/auth/me` for one token. A read younger than the TTL is
     * reused; an older one is answered at once while a new read runs behind it.
     */
    private me;
    private read;
    /**
     * Start the plugin's own sign-in.
     * @param open - open the system browser (false: the page opens the link itself).
     * @returns the authorization link and whether a browser was opened.
     */
    signIn(open: boolean): Promise<{
        url: string;
        expiresAt: number;
        opened: boolean;
    }>;
    /** Stop a waiting sign-in. */
    cancel(): void;
    /**
     * End the plugin's own sign-in.
     * @returns false when the credential is the app's account, which is signed out in the app.
     */
    signOut(): Promise<boolean>;
    /** Stop the pending reads after a charge (the plugin is going away). */
    dispose(): void;
}
/**
 * The account routes.
 * @param account - the account service.
 * @returns routes for the client connection.
 */
export declare function accountRoutes(account: AccountService): ConnectionFetchRoute[];
