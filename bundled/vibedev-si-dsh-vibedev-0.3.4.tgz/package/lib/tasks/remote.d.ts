/**
 * Reading the gateway's asynchronous task objects: `POST /v1/videos` and
 * `GET /v1/videos/{id}` (OpenAI video shape plus the gateway's `effective`
 * receipt and `asset`), and `POST /v1/audio/generations` and
 * `GET /v1/audio/generations/{id}` (`outputs[]`). Unknown statuses count as
 * still running; only an explicit terminal status ends a task.
 *
 * Both kinds carry the same settlement facts in `effective`: `billing_status`
 * (`pending`/`settled`), `billing_pending_reason`, `charged_cny` (kept as the
 * exact string given), `billed_tokens` and `estimated_cny`. A completed task
 * whose billing is pending has its result; only the charge is still to come.
 * @module dsh-vibedev/tasks/remote
 */
/** One produced file as the gateway describes it. */
export interface RemoteOutput {
    /** Position in `outputs[]`, for `/content?index=N`. */
    readonly index: number;
    readonly url?: string;
    readonly contentType?: string;
    readonly title?: string;
    /** Playback length. */
    readonly durationSeconds?: number;
    /** The provider's original length this output is billed on, when it differs from playback (speech). */
    readonly originalSeconds?: number;
}
/** A task's state. */
export interface RemoteTask {
    readonly id: string;
    /**
     * `completed` also covers `settlement_pending`: the result exists and is
     * saved, only the charge is still being settled — it is never generated again.
     */
    readonly state: 'pending' | 'completed' | 'failed';
    /** The gateway's own status word. */
    readonly status: string;
    /** Percent done, when the gateway reports it. */
    readonly progress?: number;
    readonly error?: {
        readonly code: string;
        readonly message: string;
    };
    /** Estimated price at submission (CNY, two decimals). */
    readonly estimatedCny?: string;
    /**
     * Charge (CNY) exactly as the gateway wrote it (`3.98066354`); absent until the gateway
     * reports one, which is not the same as free. Final only while `settlement` is not `pending`.
     */
    readonly chargedCny?: string;
    /**
     * Whether the charge of a finished task has settled: `effective.billing_status`,
     * `settlement_state`/`settlement_status` or the status `settlement_pending`. An explicit
     * pending wins over anything else in the same answer. Absent when no known word is given.
     */
    readonly settlement?: 'pending' | 'settled';
    /** The answer carried a billing or settlement status at all (older gateways send none). */
    readonly billingStatusReported: boolean;
    /** Why the settlement is pending (`billing_pending_reason`). */
    readonly settlementPendingReason?: string;
    /** The billable video Tokens the charge is based on (`billed_tokens`). */
    readonly billedTokens?: number;
    /** The billed original length of the whole task, in seconds (speech). */
    readonly billedOriginalSeconds?: number;
    /** The billed input length, in minutes (transcription). */
    readonly billedMinutes?: number;
    readonly outputs: readonly RemoteOutput[];
}
/**
 * Read a video task.
 * @param body - the parsed answer.
 * @returns the task, or undefined when the answer names no task id.
 */
export declare function parseVideoTask(body: unknown): RemoteTask | undefined;
/**
 * Read a music or podcast task.
 * @param body - the parsed answer.
 * @returns the task, or undefined when the answer names no task id.
 */
export declare function parseAudioTask(body: unknown): RemoteTask | undefined;
