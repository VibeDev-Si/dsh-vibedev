# @vibedev-si/dsh-vibedev · VibeDev 账号与模型

在 DeepSeek Harness 里登录 VibeDev 账号，和 DeepSeek 账号并存：

- **VibeDev 的模型**：登录后，模型选择器里会多出「VibeDev」一组（Claude、GPT 等网关提供的模型），和 DeepSeek 的模型并列，选中就能用；
- **媒体生成**：Agent 可以生成图片、视频、音乐、播客和语音，并把语音转成文字，结果保存在工作区的 `media/` 目录下；
- **网页搜索**：提供走 VibeDev 网关的网页搜索，见下面的「网页搜索」。

费用都从你的 VibeDev 余额里扣，DeepSeek 账号照常由 DeepSeek Harness 自己管理，两边互不影响。还没有 VibeDev 账号的话，可以在 [VibeDev](https://api.vibedev.studio) 注册。

本插件由 `dsh-media` 改名而来，见下面的「从 dsh-media 升级」。

[English](#english)

## 安装

- **插件页**：在 DeepSeek Harness 的插件页按包名安装 `@vibedev-si/dsh-vibedev`（包名要带 `@vibedev-si/` 前缀）。也可以先装 [VibeDev 插件中心](https://github.com/VibeDev-Si/dsh-ecosystem)，在里面一键安装。
- **命令行**：

  ```bash
  dsh plugin add @vibedev-si/dsh-vibedev
  ```

- **桌面版命令行**：先完全退出桌面版，然后运行：

  ```bash
  dsh plugin --profile desktop add @vibedev-si/dsh-vibedev
  ```

- **VibeDev 应用**：已内置本插件，不用另装。VibeDev 账号就是应用的主账号：侧边栏最底下一行和设置里的第一项都是它，DeepSeek 账号作为第二个账号显示在它上方。

新版本在 npm 上发布后的 24 小时内，只写包名可能装到上一个版本（pnpm 默认不装发布未满一天的版本），想马上用新版就写明版本号，例如 `@vibedev-si/dsh-vibedev@0.2.5`。

## 登录 VibeDev

在侧边栏底部点「登录 VibeDev」，或打开「设置 → VibeDev 账号」点「登录 VibeDev」。系统浏览器会打开 VibeDev 的登录页：账号密码是在 VibeDev 自己的网页上输入的，插件拿不到你的密码。登录完成后回到应用，侧边栏底部会显示「VibeDev 已登录」，模型选择器里随即出现 VibeDev 的模型。

「设置 → VibeDev 账号」里能看到当前账号、余额和 VibeDev 模型的数量，可以充值、查看用量明细、退出登录。登录会自动续期；退出后 VibeDev 的模型会从选择器里消失，DeepSeek 账号不受影响。

0.2.3 起修复了重启后再次要求登录的问题：启动时凭据服务未就绪或临时读取失败，会在服务就绪后恢复，不把空结果永久缓存；正常关闭应用保留登录。过去写到本地备用文件的会话在宿主凭据服务可用后迁入，宿主已有记录优先，显式退出会清理备用会话。VibeDev 应用内置的插件需要随应用升级到修复版；单独安装在 DeepSeek Harness 中的插件可直接升级。

0.2.5 起撤回了 0.2.4 加在「设置 → VibeDev 账号」页尾的「创作工具」推荐行：那一行属于插件之间的推荐位，放在设置页会影响观感，等重新设计后再考虑。撤销只涉及这一处界面，账号、余额、模型列表、登录与已保存的剧本分镜作品都不受影响。

## VibeDev 的模型

正式默认 API 为 `https://api.vibedev.studio`。从旧版升级后须重新登录，才会获取本站模型；登录仍使用 S256 PKCE、state、随机 localhost 回调和 app token，不使用共享 HMAC secret。充值、注册、用量链接跟随所选 API origin，网页搜索也使用该 API 的 `/v1/vibedev/web-search`。

所有网关的凭据键、设备记录和媒体任务目录均按规范化 gateway origin 隔离，只接受带匹配 origin 标记的登录记录。原 `dsh-media/vibedev-session` 和未标注的数据目录保留在本地，但不再读取、导入或自动恢复、重新提交其中的旧视频、音频与上传状态。DeepSeek 等其它账号、聊天、工作区及历史媒体 URL 不改写；已有美国 origin 登录记录可继续使用。

媒体创建、完成、刷新请求走所选 API；上传和下载使用服务器返回的完整签名 URL，保留 host、path、query，不携带 VibeDev app token。返回签名链接时下载不再先探测旧 `/content` 接口；未返回链接的旧接口仍可直接返回文件。API 和下载请求拒绝重定向，不把失败或503当作跨区域重发理由。现有同站同键重试、SSE、心跳和取消语义保留。默认不读取开发密钥，旧 `VIBEDEV_GATEWAY_API_KEY` 变量不再使用；开发调试需显式指定本站专用环境变量。本地验证版不解除服务器503挡板，不发送真实模型或付费媒体测试。

- 模型列表来自 VibeDev 网关，按你的账号下发，所以**未登录时不显示**，登录后立即出现，不用重启。
- 模型在选择器里的「VibeDev」组；默认模型仍是 DeepSeek Harness 原来的，想用 VibeDev 的模型就在选择器里选。
- 没登录就用了 VibeDev 的模型，或登录已失效时，对话里会提示到侧边栏或设置里登录；余额不足时会提示并给出充值链接。这些提示和 DeepSeek 账号的登录、充值提示是分开的。
- 访问令牌过期时插件会自动续期并重发请求，不会重复输出。
- 网关到上游模型服务的连接中途断开（例如 `upstream_http2_stream_error`、上游响应流被中断）属于可恢复的传输故障，会和超时、5xx、限流一样按退避自动重试，不再直接判定成一次不可重试的失败；重试会重新发起该次请求，已经输出的内容不会续写。

## 网页搜索

插件注册了一个网页搜索提供方 `vibedev-gateway`，用你的 VibeDev 登录调用网关的搜索。注册不等于启用：DeepSeek Harness 默认仍用自己的搜索；想改用 VibeDev 的，在配置文件里把 `web` 一行的 `searchProvider` 设为 `vibedev-gateway`（VibeDev 应用默认就是这样）。搜索本身不收费，但余额为零时网关会拒绝所有请求，包括搜索。

## 媒体工具

| 工具 | 用途 |
| --- | --- |
| `image_generate` | 生成图片；带参考图时用来改图、换风格或把产品放进场景。生成的图片 Agent 自己能看到。 |
| `video_generate` | 生成视频，在后台运行，一般 1 到 10 分钟。完成后会通知 Agent，文件保存在 `media/videos/`。 |
| `audio_generate` | 生成音乐（可以自带歌词）、一期播客（围绕一个话题或一个网页），或一段语音（朗读文字，可以用参考音频指定音色）。 |
| `audio_transcribe` | 把语音转成文字（以文件上传，语言和时长限制以模型声明为准，目前常见为普通话）。 |
| `media_models` | 列出账号可用的媒体模型和价格；视频模型还会列出每种模式接受哪些输入。 |
| `media_tasks` | 查看进行中和已完成的视频、音频任务。 |
| `media_account` | 查看用的是哪个 VibeDev 账号；登录或退出（和侧边栏、设置里的登录是同一个）。 |

### 参考素材

参考图、参考视频、参考音频、首帧和尾帧可以用下面几种方式给出：

- 工作区里的文件路径，例如 `assets/product.png`；
- http(s) 链接；
- `chat:1`：你在对话里发送的、最近一个对应类型的文件（`chat:2` 是再往前一个），也可以写明类型，例如 `chat:image:1`、`chat:video:1`。

每个视频模型支持的模式、参考素材数量、时长、画面比例和分辨率都不一样。插件会按网关下发的模型能力逐项检查：模型不支持的请求，会在上传和扣费之前就被拒绝，并说明这个模型支持什么。所有参考素材会先上传到 VibeDev 网关的素材库，网关会检查格式，并测量参考视频的时长。

### 音频模型

音频模型是音乐、播客、语音还是转写，只看网关模型目录里 `audio.generation_kind` 的声明，不按模型名称猜；没有声明类型的模型会列出来，但不能用来生成。每个模型只提交它在 `request_fields` 里声明的字段，正文写进 `prompt_field` 指定的字段：

- 音乐：`prompt`、`lyrics`、`genre`、`mood`、`gender`；
- 播客：`prompt`、`source_url`；
- 语音：按模型声明，例如 Seed 是 `text_prompt`、`references`（参考音频）、`audio_config`（输出格式和采样率）、`watermark`。

参考音频的数量、大小、时长、不能同时使用的字段，以及 WAV、MP3 等格式各自支持的采样率，都以网关下发的能力为准。音乐和播客不接受参考音频、格式、采样率或时长参数。

## 费用

- VibeDev 的聊天模型按用量计费，价格以 VibeDev 网关为准。
- 图片按张计费，视频按秒计费（参考视频的时长也计入），音乐和播客按次计费，语音按原始秒计费（按服务商返回的原始时长，可能和播放时长不同），转写按分钟计费。`media_models` 会列出当前价格；目录没有给出价格的模型显示「未定价」，不代表免费。
- 按视频 Token 计价的模型（目录里的 `video_pricing`）按分辨率和有无参考视频、参考音频、参考图（含首尾帧）分档，例如「480p 无参考视频 ¥60.06/百万 Token（预计 ¥0.5819/秒）」。生成前的金额只是预估：每秒预估价 ×（输出时长 + 所有参考视频时长），最终按实际视频 Token 结算。参考视频时长未知、目录没有每秒预估价或计价方式当前版本不支持时，显示「无法预估；按实际视频 Token 用量结算」，不会当成免费或未定价。视频生成后费用仍在确认（`billing_status: pending`）时，视频照常保存，只是费用待确认，不会重新生成。
- 视频和音频只在成功时扣费，失败和取消的任务不扣。视频提交后无法取消。
- 同一次操作只会生成一次：提交没有得到确认时，会用同一个请求键向网关确认结果；查询或下载失败只会重新查询、刷新链接，不会重新提交。结果已经生成、但费用还在结算（`settlement_pending`）时，结果照常保存，不会重新生成。
- 余额在每次付费请求结束后（对话回复、生成、转写）马上重新读取，侧栏和设置页几秒内就能看到扣费后的余额。
- 插件设置里的「每次付费生成前先询问」默认关闭。打开后，每次付费的媒体请求之前都会先弹出确认，并显示预估金额。

## 设置

在侧边栏的「插件」页打开「VibeDev 账号与模型」，可以修改下面这些设置，改完点「保存」。

| 设置 | 默认值 | 说明 |
| --- | --- | --- |
| 每次付费生成前先询问 | 关 | 打开后，每次媒体生成前先确认费用。 |
| 保存目录 | `media` | 相对于工作区。 |
| 默认生图 / 视频 / 音乐 / 播客 / 语音合成 / 转写模型 | 空 | 留空时由 Agent 按模型目录选择；可以填模型 id 或别名。 |

另有几项只能在配置文件（`cordis.patch.yml` 中 `dsh-vibedev` 一行）里改：`displayName`（模型选择器里显示的组名，默认 `VibeDev`）、`preferredModels`（排在最前的 VibeDev 模型）、`openBrowserOnSignIn`（登录时是否自动打开系统浏览器，默认开）、`catalogRefreshMinutes`（模型目录刷新间隔，默认 30 分钟）、`client`（登录时报给网关的客户端名称，默认 `vibedev-plugin`）、`primary`（作为应用的主账号显示，默认关，VibeDev 应用里开）。

## 从 dsh-media 升级

- 在 VibeDev 插件中心（0.1.5 起）里点「一键切换」，或直接安装本插件、影视工作台或 AI 创作套装，都会自动切换：先装新包但不启用，再停用 `dsh-media`、启用新包，新包启用成功后才卸载旧包；新包启用失败时会把旧包重新启用。
- 手动升级：先在插件页停用 `dsh-media`，再安装 `@vibedev-si/dsh-vibedev`，然后卸载 `dsh-media`，完全退出再打开应用。两个不能同时启用：它们注册同名的工具，后加载的那个会启动失败。
- 登录状态、进行中的视频和音频任务都会保留，不用重新登录。插件页里的媒体设置（花费确认、保存目录、默认模型）会回到默认值，需要的话重新设一下。

## 隐私

提示词和参考素材会发送到 VibeDev 网关，再由网关转交给对应的模型服务商；生成结果保存在你的工作区。插件自己的登录凭据保存在 DeepSeek Harness 的凭据存储里；任务记录保存在 DeepSeek Harness 数据目录下的 `dsh-media/` 中（沿用旧名，升级时不丢）。

## 给其他插件用

插件注册了一个 `vibedevMedia` 服务，其他插件可以用它生成图片和视频，走的是同一套模型选择、参考素材检查、幂等提交和后台保存。影视工作台（[dsh-film](https://github.com/VibeDev-Si/dsh-film)）的分镜画布就是通过它生成的。调用方已经向用户显示过价格，所以不会再触发「每次付费生成前先询问」。

## 开发

```bash
npm install
npm test
npm run build
```

`npm run build` 把宿主端打包进 `lib/`：DeepSeek Harness 自己的包（`@deepseek-ai/*`）由宿主提供、不打包，pi-ai 及 Anthropic、OpenAI 的 SDK 打包进来，所以安装插件时不会运行任何依赖的安装脚本；同时生成 `THIRD-PARTY-NOTICES.txt`。`npm pack` 之前会运行 `npm run check:package` 检查包内容。

## 第三方代码

`src/llm/` 的模型线路移植自 VibeDev 应用；其中 `context.ts`、`replay.ts`、`stream.ts` 复制自 DeepSeek Harness 的 `@deepseek-ai/dsh-llm-pi-ai`（MIT）。打包进来的 pi-ai、Anthropic SDK、OpenAI SDK 等的许可文本见包内的 `THIRD-PARTY-NOTICES.txt`。

---

## English

**American API default**: production defaults to `https://api.vibedev.studio`. Upgrades from unscoped historical state require a new app-token login before listing models. Every origin has separate credentials, devices and durable media tasks; grants must carry a matching origin. Historical unmarked files and the old credential record stay intact but are never read, imported, resumed or resubmitted. Existing American-origin grants remain usable. Other accounts, chats, workspaces and historical media URLs are unchanged. API control requests, account web links and web search follow the selected origin; uploads/downloads preserve the server's complete signed URL without an app token. Redirects and cross-region fallback are refused. S256 PKCE, state, random localhost callback, SSE, heartbeats, cancellation and same-origin idempotency remain. Developer-key fallback is disabled by default and the old shared environment variable is ignored; development requires an explicitly named gateway-specific variable. Local verification neither removes the server's 503 gate nor sends real model or paid media tests.

Sign in to VibeDev in DeepSeek Harness, next to the DeepSeek account:

- **VibeDev models**: once signed in, the model picker gains a "VibeDev" group (Claude, GPT and the other models of the VibeDev gateway) next to DeepSeek's;
- **Media generation**: the agent generates images, videos, music, podcasts and speech, and transcribes speech; results are saved in the workspace under `media/`.

Everything is paid from your VibeDev balance; the DeepSeek account stays DeepSeek Harness's own, and the two do not affect each other. To create an account, register at [VibeDev](https://api.vibedev.studio). This plugin was renamed from `dsh-media`.

**Install**: install `@vibedev-si/dsh-vibedev` by package name on the Plugins page (the `@vibedev-si/` scope is required), or from the [VibeDev Plugin Center](https://github.com/VibeDev-Si/dsh-ecosystem); from the command line, `dsh plugin add @vibedev-si/dsh-vibedev`, or `dsh plugin --profile desktop add @vibedev-si/dsh-vibedev` for the desktop app (quit it fully first). The VibeDev app ships with the plugin built in, and there the VibeDev account is the main account (the bottom row of the sidebar and the first Settings section), with the DeepSeek account as the second one. Within 24 hours of a release, name the version (e.g. `@vibedev-si/dsh-vibedev@0.2.5`): pnpm does not install versions younger than a day by default.

**Signing in**: choose "Sign in to VibeDev" at the bottom of the sidebar or in Settings → VibeDev account. The VibeDev sign-in page opens in your system browser: you type your password on VibeDev's own page, never in the plugin. Settings → VibeDev account shows the account, the balance and how many VibeDev models are listed, and lets you top up, see usage and sign out.

**Sign-in persistence (0.2.3)**: an early empty or failed startup read is retried when storage becomes ready, and committed credential changes restore the account and model route. A late read cannot overwrite a newly saved sign-in. Normal app exit keeps the sign-in. A session saved in the local fallback is migrated into an available host store without overwriting an existing host record; signing out clears the fallback as well. A built-in copy is upgraded by updating VibeDev, while a separately installed plugin can be upgraded directly.

**Creator tools withdrawn (0.2.5)**: the Creator tools line 0.2.4 added at the end of Settings → VibeDev account is gone. It was a cross-plugin recommendation slot, and in the settings page it hurt the layout; a redesign can revisit it later. Only that interface change is reverted: the account, the balance, the model list, the sign-in and saved screenplays, boards and film files are untouched.

**Gateway audio (0.3.1)**: audio models are recognized from the catalog's structured `audio` block (music, podcast, speech, transcription), never from their names; speech generation (Seed) joins music and podcasts; prices show their unit (per generation, per second of original audio, per minute) and "not priced" when the catalog states none; the `vibedevMedia` service gains `startAudio` with an operation key and query-only result reading.

**Balance without the wait (0.3.2)**: the balance is read again right after a paid request ends (a chat reply, a generation, a transcription) and the account pages hear it through a long poll, so a charge shows within seconds instead of after up to two minutes. A page that already has a balance is answered at once while a newer one is read behind it; reads after charges are at least five seconds apart.

**Models**: the list comes from the VibeDev gateway for your account, so nothing is listed before you sign in; models appear right after, without a restart. Using a VibeDev model while signed out, or after the sign-in has ended, asks you to sign in; a used-up balance says so with the top-up link. These messages are separate from the DeepSeek account's. An expired access token is renewed and the request sent again, without repeating any output.

**Web search**: the plugin registers the web search provider `vibedev-gateway`, signed in with your VibeDev account. Registering does not select it: DeepSeek Harness keeps its own search unless the profile sets `searchProvider: vibedev-gateway` on the `web` row (the VibeDev app does). Searching is free, but the gateway refuses every request, searches included, while the balance is zero.

**Media tools**: `image_generate`, `video_generate` (runs as a background job), `audio_generate` (music, a podcast or speech), `audio_transcribe` (a multipart file upload; languages and limits as each model declares), `media_models`, `media_tasks` and `media_account`. Reference images, videos and audio, and first and last frames, can each be a workspace path, an http(s) link, or `chat:1` for the most recent matching file you attached. A request the model cannot serve is refused before anything is uploaded or charged.

**Audio models**: whether an audio model makes music, a podcast, speech or a transcription comes from its catalog declaration (`audio.generation_kind`), never from its name; a model that declares no kind is listed but cannot generate. Each model is sent only the fields it declares in `request_fields`, with the text in its `prompt_field`: music takes `prompt`, `lyrics`, `genre`, `mood` and `gender`; a podcast `prompt` and `source_url`; speech what it declares (Seed: `text_prompt`, `references`, `audio_config`, `watermark`). Speech reference limits (count, size, length, exclusions) and the sample rates of each output format come from the gateway. Music and podcasts take no references, format, sample rate or duration.

**Cost**: chat models are billed by usage at the gateway's prices; images per image, video per second (reference video length counts), music and podcasts per request, speech per second of original audio (the length the provider reports, which can differ from playback), transcription per minute. A model without a catalog price is shown as "not priced" (未定价), never as free. Video models priced per video Token (`video_pricing` in the catalog) have one Token price per resolution and presence of reference video, audio and images (first and last frames count as images); before a run the plugin estimates the matching rule's per-second price times the output length plus every reference video's length, and the final charge is the actual video Tokens. When that cannot be estimated (an unmeasured reference video, no per-second estimate, a pricing mode this version does not read) it says "estimate unavailable; billed by actual video Token usage" — never free, never "not priced". A finished video whose billing is still pending (`billing_status: pending`) is saved as usual and never generated again; only the charge is still to be confirmed. Failed and cancelled video and audio tasks are not charged, and a submitted video cannot be cancelled. One operation generates once: an unconfirmed submission is settled under the same key, a failed query or download only queries again or renews the link, and a result whose charge is still settling (`settlement_pending`) is kept, never generated again. "Ask before each paid generation" is off by default.

**Settings**: open "VibeDev Account & Models" on the Plugins page for the spending confirmation, the output folder and the default media models. `displayName`, `preferredModels`, `openBrowserOnSignIn`, `catalogRefreshMinutes`, `client` (the client name sent with the sign-in, default `vibedev-plugin`) and `primary` (show the account as the app's main account; off by default, on in the VibeDev app) are set in the profile's `cordis.patch.yml` row `dsh-vibedev`.

**Upgrading from dsh-media**: the VibeDev Plugin Center (0.1.5 or later) switches it over for you, from its banner or when you install this plugin, the film workbench or the AI Creator Suite: the new package is installed disabled, `dsh-media` is disabled, the new one enabled, and `dsh-media` removed only after that worked. By hand, disable `dsh-media` first, install `@vibedev-si/dsh-vibedev`, uninstall `dsh-media` and restart the app fully. The two cannot both be enabled: they register the same tool names, and whichever loads second fails to start. The sign-in and running video and audio tasks carry over; the media settings go back to their defaults.

**Privacy**: prompts and reference media are sent to the VibeDev gateway, which forwards them to the model provider. The plugin's own sign-in is kept in the DeepSeek Harness credential store, and task records under `dsh-media/` in the DeepSeek Harness data folder (the former name, kept so an upgrade loses nothing).

**For other plugins**: the `vibedevMedia` service generates images, videos and audio (`startAudio`: music, podcasts and speech) through the same model choice, reference checks, idempotent submission and background saving; the film workbench ([dsh-film](https://github.com/VibeDev-Si/dsh-film)) storyboard uses it. `audioForms()` describes the form of each audio model (only its declared fields, choices and limits, and its price). `videoQuote(request)` quotes a video request from the cached catalog alone (no upload, no submission): a video Token estimate with its rule and basis, a legacy estimate, or why there is none. Task views carry `settlement`, `settlementPendingReason`, `chargedCny` (only once settled, exactly as the gateway wrote it) and `billing.tokens`. Every task is read the same way: `task` (as recorded), `refreshTask` (ask the gateway again — fresh links, settlement; a query, never a submission), `onTask` (each change) and `result` (the files to play or download). Pass the same `operationId` when one click is retried: its task is returned and nothing is submitted twice.

**Third-party code**: the model route in `src/llm/` is ported from the VibeDev app; `context.ts`, `replay.ts` and `stream.ts` are copied from DeepSeek Harness's `@deepseek-ai/dsh-llm-pi-ai` (MIT). The licences of the bundled pi-ai, Anthropic SDK, OpenAI SDK and their dependencies are in `THIRD-PARTY-NOTICES.txt`.

## Login diagnostics (0.2.8-us.3) · 登录诊断

登录状态区分等待浏览器、交换登录凭据、保存凭据与成功、失败、取消、过期；设置页面和新版 VibeDev Next 欢迎页显示网络、超时、授权拒绝、服务不可用、响应异常、本地存储或回调错误。折叠的诊断信息及 Host 日志只记录尝试编号、阶段、目标 origin、HTTP 状态和受控网络错误码，不记录账号密码、授权码、PKCE verifier、token、响应正文或完整回调链接。保持 PKCE、state 与随机 localhost 回调；交换失败不会自动重发或切换网关。美国网页公开配置仍需服务维护方单独核对。

Login distinguishes waiting for the browser, exchanging credentials, saving credentials, and successful, failed, cancelled or expired outcomes. Settings and the updated VibeDev Next welcome page show classified failures. Collapsible support details and Host logs contain only the attempt reference, phase, origin, HTTP status and allowlisted network codes. Passwords, authorization codes, PKCE verifiers, tokens, response bodies and full callback URLs are excluded. PKCE, state and the random localhost callback remain; a failed exchange is never automatically repeated or sent to another gateway. The gateway operator must separately verify the American web page's public configuration.

## Maintainer releases

Build, typecheck and test locally, pack the tested archive, tag the matching source version, and publish a GitHub Release with `vibedev-si-dsh-vibedev-<version>.tgz` attached. `.github/workflows/publish.yml` publishes that exact archive with npm OIDC; it does not rebuild the package. The job checks the source/tag/archive identities and Release asset digest, refuses an existing version with different bytes, and skips an identical already-published version. It verifies the complete npm tarball after publication. For a manual retry of an unpublished version, run the workflow on the version's tag ref.

Configure npm Trusted Publisher with GitHub owner `VibeDev-Si`, repository `dsh-vibedev`, workflow `publish.yml`, no environment, and **Allow npm publish**. Enable **Allow npm dist-tag** as well to use the manual `dist-tag` operation for `latest` or `next`. No npm token is stored in this repository. Trusted publishing does not authorize `npm deprecate`; that maintenance operation still uses interactive authentication.

## License

MIT
