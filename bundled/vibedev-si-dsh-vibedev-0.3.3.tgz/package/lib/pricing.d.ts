/**
 * Price estimates from the catalog's `media_pricing` (selling prices with the
 * account multiplier applied). The gateway estimates the same way at admission:
 * per-second video prices times billed seconds, where billed seconds are the
 * output length plus the summed reference video length, rounded up once.
 * Estimates are for the user's information; the gateway's receipt is the charge.
 *
 * A model without a price is "not priced" (未定价), never free: only a price the
 * catalog states as zero is shown as ¥0.
 * @module dsh-vibedev/pricing
 */
import type { MediaKind, MediaModel, PriceUnit } from './gateway/catalog.js';
/** One estimate. */
export interface Estimate {
    readonly amountCny: number;
    /** How it was reached, such as `¥0.99/s × 5 s`. */
    readonly basis: string;
}
/** Text in both languages the plugin speaks. */
export interface Bilingual {
    readonly en: string;
    readonly zh: string;
}
/** Shown wherever the catalog gives no price. */
export declare const UNPRICED: Bilingual;
/**
 * Format an amount in yuan: two decimals, more when a small unit price needs them (`¥0.015`).
 * @param amount - the amount.
 * @returns `¥4.95`.
 */
export declare function yuan(amount: number): string;
/**
 * The unit after a price: `/s`, `/原始秒`, `/次`.
 * @param unit - the price unit.
 * @param kind - the kind of model, which names a generation (an image, a video, a request).
 * @returns the suffix in both languages.
 */
export declare function unitSuffix(unit: PriceUnit, kind: MediaKind): Bilingual;
/**
 * A one-line price for listings: `¥0.10 per image`, `¥0.99/s (720p)`; `not priced` without a price.
 * @param model - the model.
 * @param lang - the language.
 * @returns the price line.
 */
export declare function describePrice(model: MediaModel, lang?: keyof Bilingual): string;
/**
 * Estimate an image request.
 * @param model - the image model.
 * @param count - images requested.
 * @returns the estimate, or undefined without a price.
 */
export declare function estimateImages(model: MediaModel, count: number): Estimate | undefined;
/**
 * Estimate a video request.
 * @param model - the video model.
 * @param duration - the requested length in seconds, when given.
 * @param resolution - the requested resolution, when given.
 * @param referenceMs - the summed length of the reference videos.
 * @returns the estimate, or undefined without a price.
 */
export declare function estimateVideo(model: MediaModel, duration: number | undefined, resolution: string | undefined, referenceMs?: number): Estimate | undefined;
/** What an audio request costs, as far as it can be known before it runs. */
export interface AudioQuote {
    /** The catalog states a price. */
    readonly priced: boolean;
    readonly unit?: PriceUnit;
    readonly unitPriceCny?: number;
    /**
     * The amount, when it is known before the request runs: per generation, or
     * per minute of an input whose length was measured. Speech billed per
     * original second is known only once the provider reports that length.
     */
    readonly amountCny?: number;
    /** The unit price: `¥0.50/次`, `¥0.02/原始秒`, `¥0.30/分钟`, or `未定价`. */
    readonly label: Bilingual;
    /** How the charge is reached. */
    readonly basis: Bilingual;
}
/**
 * Quote an audio request: music, podcast and speech generation, or a transcription.
 * @param model - the audio or transcription model.
 * @param inputSeconds - for a transcription, the measured length of the input, when known.
 * @returns the quote; `priced: false` (未定价) when the catalog gives no usable price.
 */
export declare function quoteAudio(model: MediaModel, inputSeconds?: number): AudioQuote;
