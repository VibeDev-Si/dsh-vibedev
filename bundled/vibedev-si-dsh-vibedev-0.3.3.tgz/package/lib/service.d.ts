/**
 * The media service other plugins call, registered as `vibedevMedia`: the
 * film workbench's storyboard generates through it when someone presses a
 * generate button. It takes the same paths as the agent tools — model
 * choice, reference checks and uploads, idempotent submission, a background
 * follower that saves the result — with the caller naming the workspace and
 * where results go. The caller has already shown the price and the user chose
 * to go ahead, so the spending confirmation setting does not ask again.
 *
 * Every task, video or audio, is read the same way: {@link MediaHostService.task}
 * (what is recorded), {@link MediaHostService.refreshTask} (ask the gateway again:
 * fresh links, settlement — a query only, it never submits),
 * {@link MediaHostService.onTask} (each change) and
 * {@link MediaHostService.result} (the files to play or download).
 * @module dsh-vibedev/service
 */
import type { AudioForm, AudioRequest } from './audio/request.js';
import type { MediaModel } from './gateway/catalog.js';
import type { AudioQuote } from './pricing.js';
import type { MediaRuntime } from './runtime.js';
import type { TaskRecord, TaskStatus } from './tasks/store.js';
import type { ImageRequest } from './tools/image.js';
import type { VideoRequest } from './tools/video.js';
/** Where a host request runs and where its results go. */
export interface HostTarget {
    /** The workspace; relative input paths resolve against it. */
    readonly cwd: string;
    /** Absolute folder the results are saved in. */
    readonly folder: string;
    /** File-name stem of the results. */
    readonly stem: string;
}
/** One produced file, as host callers see it. */
export interface MediaOutputView {
    /** Where it was saved; absent while it could not be downloaded. */
    readonly path?: string;
    /** The gateway's link (signed; it expires — {@link MediaHostService.result} renews it). */
    readonly url?: string;
    readonly contentType?: string;
    readonly title?: string;
    /** Playback length. */
    readonly durationSeconds?: number;
    /** The original length it is billed on (speech), when it differs from playback. */
    readonly originalSeconds?: number;
}
/** A video or audio task, as host callers see it. */
export interface MediaTaskView {
    readonly id: string;
    readonly kind: TaskRecord['kind'];
    /** For audio: music, podcast or speech. */
    readonly audioKind?: string;
    readonly model: string;
    readonly status: TaskStatus;
    readonly progress?: string;
    readonly outputs?: readonly MediaOutputView[];
    readonly error?: {
        readonly code: string;
        readonly message: string;
    };
    readonly estimatedCny?: string;
    readonly chargedCny?: string;
    /**
     * `pending`: the result is there, the charge is still being settled (it is
     * never generated again); `settled`: `chargedCny` is final.
     */
    readonly settlement?: 'pending' | 'settled';
    /** How it is billed: the unit, the unit price, and the billed length once known. */
    readonly billing?: TaskRecord['billing'];
    readonly createdAt: number;
    readonly updatedAt: number;
}
export declare class MediaHostService {
    private readonly runtime;
    readonly version: string;
    constructor(runtime: MediaRuntime, version: string);
    private call;
    /**
     * The media models this account can use (cached briefly; renewed after a sign-in, sign-out or account switch).
     * @param signal - cancels the request.
     * @returns the models in catalog order.
     */
    models(signal?: AbortSignal): Promise<readonly MediaModel[]>;
    /**
     * The forms to show for the audio models this account can use: one per
     * model that declares what it makes, with only the fields it takes, their
     * declared choices and limits, and its price.
     * @param signal - cancels the catalog request.
     * @returns the forms, in catalog order.
     */
    audioForms(signal?: AbortSignal): Promise<readonly AudioForm[]>;
    /**
     * The price of one audio or transcription model: `¥0.50/次`, `¥0.02/原始秒`, `¥0.30/分钟`, or 未定价.
     * @param model - the model id or alias.
     * @param signal - cancels the catalog request.
     * @returns the quote.
     */
    audioPrice(model: string, signal?: AbortSignal): Promise<AudioQuote>;
    /**
     * Generate images now and save them.
     * @param request - what to generate.
     * @param target - the workspace and where the files go.
     * @param signal - cancels the request.
     * @returns the model, the saved files, the estimate and a revised prompt.
     */
    generateImages(request: ImageRequest, target: HostTarget, signal: AbortSignal): Promise<{
        images: {
            absolutePath: string;
            mediaType: string;
            bytes: number;
        }[];
        model: string;
        estimatedCny?: string;
        revisedPrompt?: string;
    }>;
    /**
     * Submit a video. The plugin follows the task in the background and saves
     * the video when it finishes; watch it with {@link task} and {@link onTask}.
     * A submission the gateway did not confirm is resent in the background
     * under the same key, so it is reported as a task still being submitted
     * rather than as a failure.
     * @param request - what to generate.
     * @param target - the workspace and where the video goes.
     * @param signal - cancels the preparation and the submission.
     * @returns the task.
     */
    startVideo(request: VideoRequest, target: HostTarget, signal: AbortSignal): Promise<MediaTaskView>;
    /**
     * Submit music, a podcast episode or speech. Fields are checked against
     * what the model declares before anything is uploaded or charged; speech
     * references are uploaded to the gateway media library first.
     *
     * One user operation, one task: pass the same `operationId` when the same
     * click is retried and the task already recorded under it is returned —
     * nothing is submitted twice. Without one, every call is a new operation.
     * @param request - what to generate.
     * @param target - the workspace and where the audio goes.
     * @param signal - cancels the preparation and the submission.
     * @returns the task.
     */
    startAudio(request: AudioRequest, target: HostTarget, signal: AbortSignal): Promise<MediaTaskView>;
    private submit;
    /**
     * A task's current state, as recorded (no request to the gateway).
     * @param id - the task id.
     * @returns the task, or `undefined` when there is none.
     */
    task(id: string): Promise<MediaTaskView | undefined>;
    /**
     * Ask the gateway about a task again — a query, never a submission: a
     * finished task gets fresh links and its missing files are downloaded
     * again, and a pending settlement is read again. A running task is followed.
     * @param id - the task id.
     * @param signal - cancels the query.
     * @returns the task after the query, or `undefined` when there is none.
     */
    refreshTask(id: string, signal?: AbortSignal): Promise<MediaTaskView | undefined>;
    /**
     * The files of a finished task, ready to play or download: saved files by
     * path, and links renewed by a query when one is needed (a missing file, an
     * expired link). Never generates again.
     * @param id - the task id.
     * @param signal - cancels the query.
     * @returns the outputs, or `undefined` while the task has none.
     */
    result(id: string, signal?: AbortSignal): Promise<readonly MediaOutputView[] | undefined>;
    /**
     * Hear about every change to one task.
     * @param id - the task id.
     * @param listener - called with the task after each change.
     * @returns stops listening.
     */
    onTask(id: string, listener: (task: MediaTaskView) => void): () => void;
}
